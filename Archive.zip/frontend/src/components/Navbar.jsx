const Navbar = () => {
  return (
    <nav className="bg-indigo-600 text-white px-6 py-4">
      AI Resume Builder
    </nav>
  );
};

export default Navbar;
